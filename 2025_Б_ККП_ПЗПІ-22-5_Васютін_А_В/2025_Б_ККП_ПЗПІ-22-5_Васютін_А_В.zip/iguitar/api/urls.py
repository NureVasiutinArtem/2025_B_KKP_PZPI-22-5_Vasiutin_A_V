from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import *

router = DefaultRouter()
router.register('effects', EffectViewSet)
router.register('presets', PresetViewSet)
router.register('tools', ToolViewSet)
router.register('tracks', AudioTrackViewSet)
router.register('comments', CommentViewSet)
router.register('effect-presets', PresetEffectViewSet)

# preset_list = PresetEffectViewSet.as_view({
#     'get': 'list',
#     'post': 'create',
# })
# preset_detail = PresetEffectViewSet.as_view({
#     'get': 'retrieve',
#     'put': 'update',
#     'delete': 'destroy',
# })

# router.register('effects', EffectViewSet, basename='effects')
# router.register('effect-presets', PresetEffectViewSet, basename='effect-presets')
#router.register('')

urlpatterns = [
    path('', include(router.urls)),
    path('register/', RegisterView.as_view()),
    path('login/', LoginView.as_view()),
    path('api/logout/', logout_view, name='logout'),
    path('profile/tracks/', UserProfileTracksView.as_view(), name='profile-tracks'),
    path('me/', MeView.as_view()),
    path('tracks/<int:pk>/like/', LikeCreateView.as_view()),
    path('tracks/<int:pk>/repost/', RepostCreateView.as_view()),
    path('presets/user/<int:user_id>/', PresetViewSet.as_view({'get': 'presets_by_user'}), name='presets-by-user'),
    path('api/tracks/<str:filename>', ServeStaticAudio.as_view()),
    path("profile/", profile_view, name="profile"),
    path("comment/<int:track_id>/", track_detail_view, name="comment"),
    # path('effect-presets/', preset_list, name='prisset'),
    # path('effect-presets/<int:pk>/', preset_detail, name='effect-preset-detail'),
    # path('prisset/<int:pk/', preset_detail, name='preset-detail'),
    path('prisset/', preset_page_view, name='preset-page'),
    path('search/', search_view, name='search-page'),



    

    # path('effect-presets',PresetEffectViewSet.as_view()),

]
