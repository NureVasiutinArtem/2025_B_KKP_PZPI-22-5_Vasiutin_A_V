from django.contrib import admin
from .models import User, AudioTrack, Effect, Preset,PresetEffect, Tool, Like, Comment, Repost

admin.site.register(User)
admin.site.register(AudioTrack)
admin.site.register(Effect)
admin.site.register(Preset)
admin.site.register(Tool)
admin.site.register(Like)
admin.site.register(Comment)
admin.site.register(Repost)
admin.site.register(PresetEffect)

