from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import FileExtensionValidator


class User(AbstractUser):
    avatar_url = models.URLField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Effect(models.Model):
    # name = models.CharField(max_length=100)
    # description = models.TextField(blank=True)
    # parameters_json = models.JSONField()
    # is_public = models.BooleanField(default=False)
    # created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='effects')
    # created_at = models.DateTimeField(auto_now_add=True)
     EFFECT_CHOICES = [
        ('delay', 'Delay'),
        ('distortion', 'Distortion'),
        ('reverb', 'Reverb'),
        ('chorus', 'Chorus'),
        ('compressor', 'Compressor'),
        ('noise_gate', 'Noise Gate'),
        ('overdrive', 'Overdrive'),
    ]
     name = models.CharField(max_length=50, choices=EFFECT_CHOICES, unique=True)
     default_parameters = models.JSONField(default=dict)  # базовые параметры
     description = models.TextField(blank=True)
     def __str__(self):
        return self.get_name_display()

     
     

class Preset(models.Model):
    # name = models.CharField(max_length=100)
    # description = models.TextField(blank=True)
    # effects_order_json = models.JSONField()
    # is_public = models.BooleanField(default=False)
    # created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='presets')
    # created_at = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='presets')
    title = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.user.username})"

class PresetEffect(models.Model):
    """
    Эффект в пресете с параметрами, изменёнными пользователем.
    Ссылка на шаблонный Effect и свой набор параметров.
"""
    preset = models.ForeignKey(Preset, on_delete=models.CASCADE, related_name='preset_effects')
    effect = models.ForeignKey(Effect, on_delete=models.CASCADE)
    parameters = models.JSONField(default=dict)  # пользовательские параметры

    class Meta:
        unique_together = ('preset', 'effect')  # в одном пресете эффект только один раз

    def __str__(self):
        # return f"{self.effect.get_name_display()} in {self.preset.title}"
        return f"{self.effect.name} in {self.preset.title}"


class Tool(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    config_json = models.JSONField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

class AudioTrack(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='audio_tracks')
    preset = models.ForeignKey(Preset, on_delete=models.SET_NULL, null=True, blank=True, related_name='audio_tracks')
    title = models.CharField(max_length=200, blank=True)
    # audio_url = models.URLField(blank=True, null=True)
    audio_file = models.FileField(
        upload_to='tracks/',
        validators=[FileExtensionValidator(['mp3'])],
        blank=True,
        null=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

class Like(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='likes')
    track = models.ForeignKey(AudioTrack, on_delete=models.CASCADE, related_name='likes')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'track')

class Comment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments')
    track = models.ForeignKey(AudioTrack, on_delete=models.CASCADE, related_name='comments')
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

class Repost(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reposts')
    track = models.ForeignKey(AudioTrack, on_delete=models.CASCADE, related_name='reposts')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'track')
        
AUTH_USER_MODEL = 'api.User'
