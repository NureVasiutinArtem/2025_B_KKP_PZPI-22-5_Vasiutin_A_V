from rest_framework import serializers
from .models import *
from django.contrib.auth import get_user_model

User = get_user_model()

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email']

class EffectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Effect
        # fields = '__all__'
        fields = ['id', 'name', 'description', 'default_parameters']
        read_only_fields = ['id', 'name', 'description', 'default_parameters']

# class PresetSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Preset
#         # fields = ['id', 'name', 'user', 'preset_effects']
#         fields = ['id', 'user', 'title', 'created_at']
#         read_only_fields = ['id', 'created_at']
#         # fields = '__all__'
#         def create(self, validated_data):
#             preset_effects_data = validated_data.pop('preset_effects', [])
#             preset = Preset.objects.create(**validated_data)

#             for pe_data in preset_effects_data:
#                 PresetEffect.objects.create(preset=preset, **pe_data)

#             return preset

#         def update(self, instance, validated_data):
#             preset_effects_data = validated_data.pop('preset_effects', [])

#             instance.name = validated_data.get('name', instance.name)
#             instance.save()

#             # Обновляем PresetEffect'ы
#             instance.preset_effects.all().delete()
#             for pe_data in preset_effects_data:
#                 PresetEffect.objects.create(preset=instance, **pe_data)

#             return instance

class PresetEffectSerializer(serializers.ModelSerializer):
    class Meta:
        model = PresetEffect
        fields = ['effect', 'parameters']

class PresetSerializer(serializers.ModelSerializer):
    preset_effects = PresetEffectSerializer(many=True)
    user = serializers.PrimaryKeyRelatedField(read_only=True)

    class Meta:
        model = Preset
        fields = ['id', 'user', 'title', 'created_at', 'preset_effects']
        read_only_fields = ['id', 'created_at', 'user']

    # def create(self, validated_data):
    #     preset_effects_data = validated_data.pop('preset_effects', [])
    #     user = self.context['request'].user
    #     preset = Preset.objects.create(user=user, **validated_data)

    #     for pe_data in preset_effects_data:
    #         PresetEffect.objects.create(preset=preset, **pe_data)

    #     return preset
    def create(self, validated_data):
        preset_effects_data = validated_data.pop('preset_effects', [])

    # Видаляємо user, якщо він переданий з клієнта
        validated_data.pop('user', None)
        user = self.context['request'].user
        preset = Preset.objects.create(user=user, **validated_data)

        for pe_data in preset_effects_data:
            PresetEffect.objects.create(preset=preset, **pe_data)

        return preset


    def update(self, instance, validated_data):
        preset_effects_data = validated_data.pop('preset_effects', None)

        instance.title = validated_data.get('title', instance.title)
        instance.save()

        if preset_effects_data is not None:
            instance.preset_effects.all().delete()
            for pe_data in preset_effects_data:
                PresetEffect.objects.create(preset=instance, **pe_data)

        return instance

# class PresetEffectSerializer(serializers.ModelSerializer):
#     effect = EffectSerializer(read_only=True)
#     effect_id = serializers.PrimaryKeyRelatedField(queryset=Effect.objects.all(), source='effect', write_only=True)

#     class Meta:
#         model = PresetEffect
#         fields = ['id', 'effect', 'effect_id', 'parameters']



class ToolSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tool
        fields = '__all__'

class AudioTrackSerializer(serializers.ModelSerializer):
    class Meta:
        audio_url = serializers.SerializerMethodField()
        
        model = AudioTrack
        fields = ['id', 'user', 'preset', 'title', 'audio_file', 'created_at']
        read_only_fields = ['id', 'created_at', 'user']
        # fields = '__all__'
        
    def get_audio_url(self, obj):
        request = self.context.get('request')
        if obj.audio_file and request:
            return request.build_absolute_uri(obj.audio_file.url)
        return None

class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = '__all__'

class LikeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Like
        fields = '__all__'

class RepostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Repost
        fields = '__all__'