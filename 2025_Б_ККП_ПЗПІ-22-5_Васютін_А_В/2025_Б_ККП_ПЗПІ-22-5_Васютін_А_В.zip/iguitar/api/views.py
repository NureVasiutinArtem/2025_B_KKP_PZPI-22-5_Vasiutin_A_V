from rest_framework import status
from rest_framework.response import Response
from rest_framework.generics import GenericAPIView
from rest_framework.authtoken.models import Token
# from django.contrib.auth import authenticate, get_user_model

# from .serializers import RegisterSerializer, LoginSerializer
from django.shortcuts import get_object_or_404
from rest_framework import generics, viewsets, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from .models import *
from .serializers import *
from rest_framework.decorators import action
from rest_framework.parsers import MultiPartParser, FormParser

import json

import os
from django.conf import settings
from django.http import FileResponse, Http404
from rest_framework.views import APIView

from django.contrib.auth.decorators import login_required

from rest_framework.permissions import IsAuthenticated

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import logout


from django.contrib.auth import login


from django.shortcuts import render
from .models import AudioTrack
def login_page(request):
    tracks = AudioTrack.objects.all()
    return render(request, 'login.html', {'tracks': tracks})


class ServeStaticAudio(APIView):
    def get(self, request, filename):
        filepath = os.path.join(settings.BASE_DIR, 'tracks', filename)
        if not os.path.exists(filepath):
            raise Http404("Файл не найден")
        return FileResponse(open(filepath, 'rb'), content_type='audio/mpeg')


class UserProfileTracksView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        tracks = AudioTrack.objects.filter(user=request.user)
        serializer = AudioTrackSerializer(tracks, many=True)
        return Response(serializer.data)
    
@login_required

# def profile_view(request):
#     user = request.user  # 👈 текущий авторизованный пользователь

#     tracks = AudioTrack.objects.filter(user=user)  # Только его треки
#     likes_count = Like.objects.filter(user=user).count()
#     presets_count = Preset.objects.filter(user=user).count()
#     presets_all = Preset.objects.filter(user=user)
#     comments = Comment.objects.filter(track__user=user).order_by("-created_at")[:3]
    
#     return render(request, "profile.html", {
#         "tracks": tracks,
#         "likes_count": likes_count,
#         "tracks_count": tracks.count(),
#         "presets_count": presets_count,
#         "last_comments": comments,
#         "presets_all":presets_all
#     })
def profile_view(request):
    user = request.user  # текущий авторизованный пользователь

    tracks = AudioTrack.objects.filter(user=user)  # только его треки
    likes_count = Like.objects.filter(user=user).count()
    presets_count = Preset.objects.filter(user=user).count()
    presets_all = Preset.objects.filter(user=user)
    comments = Comment.objects.filter(track__user=user).order_by("-created_at")[:3]

    liked_track_ids = set(
        Like.objects.filter(user=user).values_list('track_id', flat=True)
    )
    reposted_track_ids = set(
        Repost.objects.filter(user=user).values_list('track_id', flat=True)
    )
    for track in tracks:
        efects = PresetEffect.objects.filter(preset =track.preset.id)
        for efect in efects:
            print(efect.parameters)


    return render(request, "profile.html", {
        "tracks": tracks,
        "likes_count": likes_count,
        "tracks_count": tracks.count(),
        "presets_count": presets_count,
        "last_comments": comments,
        "presets_all": presets_all,
        "liked_track_ids": liked_track_ids,
        "reposted_track_ids": reposted_track_ids,
    })
def search_view(request):
    traks = AudioTrack.objects.all()
    return render(request , "search.html" ,{
                 "tracks": traks
    })


def track_detail_view(request, track_id):
    track = get_object_or_404(AudioTrack, id=track_id)
    like_count=Like.objects.filter(track=track).count()
    repost_count=Repost.objects.filter(track=track).count()
    comments = Comment.objects.filter(track=track).order_by('-created_at')
    presetefects = PresetEffect.objects.filter(preset =track.preset)
    
    print(track.title)
    print(like_count)
    print(repost_count)
    preset_json = json.dumps([
        {
            "effect": pe.effect.id,
            "parameters": pe.parameters
        }
        for pe in presetefects
    ])
    print(preset_json)
    return render(request, 'comment.html', {
        'track': track,
        'comments': comments,
        'like_count':like_count,
        'repost_count':repost_count,
        'presetefects':presetefects,
        'preset_json':preset_json
    })



class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer


@csrf_exempt  # отключаем CSRF для упрощения
def logout_view(request):
    logout(request)  # удаляем сессию на сервере
    return JsonResponse({"detail": "Logged out"})

class LoginView(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        token = Token.objects.get(key=response.data['token'])
        login(request, token.user)  # логинит пользователя в сессию

        return Response({'token': token.key, 'user_id': token.user_id})


class MeView(generics.RetrieveUpdateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = UserSerializer

    def get_object(self):
        return self.request.user

class EffectViewSet(viewsets.ModelViewSet):
    # queryset = Effect.objects.all()
    # serializer_class = EffectSerializer
    queryset = Effect.objects.all()

    serializer_class = EffectSerializer
    permission_classes = [permissions.AllowAny]

class PresetViewSet(viewsets.ModelViewSet):
    # queryset = Preset.objects.all()
    # serializer_class = PresetSerializer
    queryset = Preset.objects.all()
    serializer_class = PresetSerializer

    def get_queryset(self):
        # Пользователь видит только свои пресеты (если нужно)
        user = self.request.user
        # return Preset.objects.filter(created_by=user)
        return Preset.objects.filter(user=user)


    def perform_create(self, serializer):
        # При создании пресета автоматически привязываем к пользователю
        # serializer.save(created_by=self.request.user)
        serializer.save(user=self.request.user)

    #@action(detail=False, methods=['get'], url_path='user/(?P<user_id>[^/.]+)')
    def presets_by_user(self, request, user_id=None):
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response({"error": "User not found"}, status=404)

        presets = Preset.objects.filter(user=user)
        serializer = self.get_serializer(presets, many=True)
        return Response(serializer.data)
    
class PresetEffectViewSet(viewsets.ModelViewSet):
    queryset = PresetEffect.objects.all()
    serializer_class = PresetEffectSerializer

# def preset_detail(request, preset_id):
#     preset = get_object_or_404(Preset, id=preset_id)
#     return render(request, 'prisset.html', {'preset': preset})
def preset_page_view(request):
    preset_id = request.GET.get('presetId')
    preset = None
    if preset_id:
        preset = get_object_or_404(Preset, id=preset_id)
    return render(request, 'prisset.html', {'preset': preset})

class ToolViewSet(viewsets.ModelViewSet):
    queryset = Tool.objects.all()
    serializer_class = ToolSerializer

class AudioTrackViewSet(viewsets.ModelViewSet):
    queryset = AudioTrack.objects.all()
    serializer_class = AudioTrackSerializer
    parser_classes = [MultiPartParser, FormParser]

    #permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

    def get_queryset(self):
        return AudioTrack.objects.all()

        # if self.request.user.is_authenticated:
        #     return AudioTrack.objects.filter(user=self.request.user)
        # return AudioTrack.objects.none()  # или AudioTrack.objects.all() — если ты хочешь отдавать все


class CommentViewSet(viewsets.ModelViewSet):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer



# class LikeCreateView(APIView):
#     permission_classes = [permissions.IsAuthenticated]

#     def post(self, request, pk):
#         Like.objects.get_or_create(user=request.user, track_id=pk)
#         return Response({"status": "liked"})

# class RepostCreateView(APIView):
#     permission_classes = [permissions.IsAuthenticated]

#     def post(self, request, pk):
#         Repost.objects.create(user=request.user, track_id=pk)
#         return Response({"status": "reposted"})
class LikeCreateView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        track = get_object_or_404(AudioTrack, pk=pk)
        like = Like.objects.filter(user=request.user, track=track).first()
        if like:
            like.delete()
            liked = False
        else:
            Like.objects.create(user=request.user, track=track)
            liked = True

        likes_count = Like.objects.filter(track=track).count()
        return Response({"liked": liked, "likes_count": likes_count})

class RepostCreateView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        track = get_object_or_404(AudioTrack, pk=pk)
        repost = Repost.objects.filter(user=request.user, track=track).first()
        if repost:
            repost.delete()
            reposted = False
        else:
            Repost.objects.create(user=request.user, track=track)
            reposted = True

        reposts_count = Repost.objects.filter(track=track).count()
        return Response({"reposted": reposted, "reposts_count": reposts_count})