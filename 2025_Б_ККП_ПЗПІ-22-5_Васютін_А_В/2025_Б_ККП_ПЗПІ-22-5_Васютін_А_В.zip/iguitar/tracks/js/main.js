document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("login-form");
    // if (loginForm) {
    //     loginForm.addEventListener("submit", function (e) {
    //         e.preventDefault();
    //         const formData = new FormData(loginForm);
    //         const data = {
    //             username: formData.get("username"),
    //             password: formData.get("password"),
    //         };

    //         fetch("/api/token/", {
    //             method: "POST",
    //             headers: {
    //                 "Content-Type": "application/json",
    //             },
    //             body: JSON.stringify(data),
    //         })
    //             .then((res) => {
    //                 if (!res.ok) throw res;
    //                 return res.json();
    //             })
    //             .then((data) => {
    //                 alert("Вход выполнен!");
    //                 console.log(data);
    //                 // можно сохранить токен в localStorage
    //             })
    //             .catch(async (error) => {
    //                 let msg = "Ошибка входа.";
    //                 if (error.json) {
    //                     const err = await error.json();
    //                     msg = JSON.stringify(err);
    //                 }
    //                 alert(msg);
    //             });
    //     });
    // }

    const registerForm = document.getElementById("register-form");
    if (registerForm) {
        registerForm.addEventListener("submit", function (e) {
            e.preventDefault();
            const formData = new FormData(registerForm);
            const data = {
                username: formData.get("username"),
                email: formData.get("email"),
                password: formData.get("password"),
            };

            fetch("/api/register/", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data),
            })
                .then((res) => {
                    if (!res.ok) throw res;
                    return res.json();
                })
                .then((data) => {
                    alert("Регистрация прошла успешно!");
                    window.location.href = "/";
                })
                .catch(async (error) => {
                    let msg = "Ошибка регистрации.";
                    if (error.json) {
                        const err = await error.json();
                        msg = JSON.stringify(err);
                    }
                    alert(msg);
                });
        });
    }
});
